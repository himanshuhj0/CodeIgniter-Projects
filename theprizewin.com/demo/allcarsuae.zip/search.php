<!DOCTYPE html>
<html lang="bg">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="Безплатни авто обяви,вип каско,авточасти,форуми">
<meta name="keywords" content="Коли, Авто, Автомобили, Търсачка, Търсачка за автомобили, Авто търсачка, Търсене на коли, Авто обяви, Обяси за коли, Продавам кола, Купувам кола, авто пазар" />
<link rel="stylesheet" href="css/s.css" />
<script type="text/javascript" src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="js/TreeController.js"></script>
<title>Untitled Document</title>
</head>

<body>
<div id="b-line"></div>
<div id="logodiv"><img src="imgs/logo.png"></div>
<header>
  <ul>
    <li><a href="index.php">Home</a></li>
    <li><a href="search.php">Search</a></li>
    <li><a href="#">Post Listing</a></li>
    <li><a href="#">About US</a></li>
    <li><a href="#">Contacts</a></li>
  </ul>
  <form>
    <input type="text" id="text" placeholder="Search">
    <input type="submit" id="submit" value="">
  </form>
</header>
<div id="slider"> <img src="imgs/slider/1.jpg" id="img1"> <img src="imgs/slider/2.jpg" id="img2" style="display:none"> <img src="imgs/slider/3.jpg" id="img3" style="display:none"> </div>
<div id="content">
<h2 id="h2-results">ALL UAE Cars </h2>
<div id="search">
 <form method="GET">
        <input type="hidden" name="page" value="search" />
        <table>
          <tr>
            <td><select class="searchTreeLevel1" name="MakeModel[tree][0]">
                <option value="">Brand</option>
                <option value="Aixam"  >Aixam</option>
                <option value="AlfaRomeo"  >Alfa Romeo</option>
                <option value="AstonMartin"  >Aston Martin</option>
                <option value="Audi"  >Audi</option>
                <option value="Bmw" >BMW</option>
                <option value="Bentley"  >Bentley</option>
                <option value="Bugatti"  >Bugatti</option>
                <option value="Buick"  >Buick</option>
                <option value="Cadillac"  >Cadillac</option>
                <option value="Chevrolet"  >Chevrolet</option>
                <option value="Chrysler"  >Chrysler</option>
                <option value="Citroen"  >Citroen</option>
                <option value="Corvette"  >Corvette</option>
                <option value="DKW"  >DKW</option>
                <option value="Dacia"  >Dacia</option>
                <option value="Daewoo"  >Daewoo</option>
                <option value="Daihatsu"  >Daihatsu</option>
                <option value="Datsun"  >Datsun</option>
                <option value="Dodge"  >Dodge</option>
                <option value="Eagle"  >Eagle</option>
                <option value="FSO"  >FSO</option>
                <option value="Ferrari"  >Ferrari</option>
                <option value="Fiat"  >Fiat</option>
                <option value="Ford"  >Ford</option>
                <option value="GMC"  >GMC</option>
                <option value="Gaz"  >Gaz</option>
                <option value="Geo"  >Geo</option>
                <option value="GreatWall"  >Great Wall</option>
                <option value="Honda"  >Honda</option>
                <option value="Hummer"  >Hummer</option>
                <option value="Hyundai"  >Hyundai</option>
                <option value="Infiniti"  >Infiniti</option>
                <option value="Innocenti"  >Innocenti</option>
                <option value="Isuzu"  >Isuzu</option>
                <option value="Jaguar"  >Jaguar</option>
                <option value="Jeep"  >Jeep</option>
                <option value="Jpx"  >Jpx</option>
                <option value="Kia"  >Kia</option>
                <option value="Lada"  >Lada</option>
                <option value="Lamborghini"  >Lamborghini</option>
                <option value="Lancia"  >Lancia</option>
                <option value="Landwind"  >Landwind</option>
                <option value="Lexus"  >Lexus</option>
                <option value="Lincoln"  >Lincoln</option>
                <option value="Lotus"  >Lotus</option>
                <option value="MG"  >MG</option>
                <option value="Mini"  >MINI</option>
                <option value="Maserati"  >Maserati</option>
                <option value="Matra"  >Matra</option>
                <option value="Maybach"  >Maybach</option>
                <option value="Mazda"  >Mazda</option>
                <option value="Mercedes"  >Mercedes</option>
                <option value="Mercury"  >Mercury</option>
                <option value="Mitsubishi"  >Mitsubishi</option>
                <option value="Morgan"  >Morgan</option>
                <option value="Moskvich"  >Moskvich</option>
                <option value="Nissan"  >Nissan</option>
                <option value="Oldsmobile"  >Oldsmobile</option>
                <option value="Opel"  >Opel</option>
                <option value="Perodua"  >Perodua</option>
                <option value="Peugeot"  >Peugeot</option>
                <option value="Plymouth"  >Plymouth</option>
                <option value="Polonez"  >Polonez</option>
                <option value="Pontiac"  >Pontiac</option>
                <option value="Porsche"  >Porsche</option>
                <option value="Proton"  >Proton</option>
                <option value="Renault"  >Renault</option>
                <option value="RollsRoyce"  >Rolls-Royce</option>
                <option value="Rover"  >Rover</option>
                <option value="Saab"  >Saab</option>
                <option value="Samand"  >Samand</option>
                <option value="Scion"  >Scion</option>
                <option value="Seat"  >Seat</option>
                <option value="Shatenet"  >Shatenet</option>
                <option value="Simca"  >Simca</option>
                <option value="Skoda"  >Skoda</option>
                <option value="Smart"  >Smart</option>
                <option value="Subaru"  >Subaru</option>
                <option value="Suzuki"  >Suzuki</option>
                <option value="Talbot"  >Talbot</option>
                <option value="Tata"  >Tata</option>
                <option value="Tavria"  >Tavria</option>
                <option value="Tempo"  >Tempo</option>
                <option value="Terberg"  >Terberg</option>
                <option value="Tesla"  >Tesla</option>
                <option value="Tofas"  >Tofas</option>
                <option value="Toyota"  >Toyota</option>
                <option value="Trabant"  >Trabant</option>
                <option value="Triumph"  >Triumph</option>
                <option value="Uaz"  >Uaz</option>
                <option value="Volga"  >Volga</option>
                <option value="Volvo"  >Volvo</option>
                <option value="Vw"  >Vw</option>
                <option value="Warszawa"  >Warszawa</option>
                <option value="Wartburg"  >Wartburg</option>
                <option value="Wiesmann"  >Wiesmann</option>
                <option value="Xinkai">Xinkai</option>
                <option value="Xinshun" >Xinshun</option>
                <option value="Zastava" >Zastava</option>
                <option value="Zaz">Zaz</option>
              </select></td>
            <script type="text/javascript">

	$(document).ready(function()

	{

		var treeData = {

					Austin:{'Allegro' : 'Allegro','Ambassador' : 'Ambassador','Maestro' : 'Maestro','Maxi' : 'Maxi','Metro' : 'Metro','Mg' : 'Mg','Mini' : 'Mini','Montego' : 'Montego','Princess' : 'Princess'},

					RollsRoyce:{'Ghost' : 'Ghost','Phantom' : 'Phantom','Silver Seraph' : 'Silver Seraph'},

					0:{'291' : 'Acura','1554' : 'Aixam','310' : 'Alfa Romeo','2830' : 'Aro','2828' : 'Asia','334' : 'Aston Martin','340' : 'Audi','1591' : 'Austin','376' : 'BMW','368' : 'Bentley','1602' : 'Berliner','2825' : 'Bertone','1667' : 'Borgward','1669' : 'Bugatti','458' : 'Buick','478' : 'Cadillac','495' : 'Chevrolet','541' : 'Chrysler','1694' : 'Citroen','1728' : 'Corvette','1771' : 'DKW','1733' : 'Dacia','567' : 'Daewoo','571' : 'Daihatsu','1765' : 'Daimler','574' : 'Datsun','590' : 'Dodge','634' : 'Eagle','1774' : 'FSO','640' : 'Ferrari','664' : 'Fiat','671' : 'Ford','2763' : 'GMC','2774' : 'Gaz','715' : 'Geo','2760' : 'Great Wall','745' : 'Honda','2751' : 'Hummer','765' : 'Hyundai','1859' : 'IFA','780' : 'Infiniti','1868' : 'Innocenti','794' : 'Isuzu','812' : 'Jaguar','2722' : 'Jeep','2720' : 'Jpx','839' : 'Kia','1894' : 'Lada','2713' : 'Laforza','850' : 'Lamborghini','857' : 'Lancia','2708' : 'Land Rover','2706' : 'Landwind','869' : 'Lexus','895' : 'Lincoln','909' : 'Lotus','2087' : 'MG','1089' : 'MINI','2687' : 'Mahindra','914' : 'Maserati','1955' : 'Matra','922' : 'Maybach','925' : 'Mazda','1976' : 'Mercedes','1068' : 'Mercury','1091' : 'Mitsubishi','2112' : 'Morgan','2114' : 'Moskvich','2136' : 'Nissan','1134' : 'Oldsmobile','2166' : 'Opel','2234' : 'PGO','2192' : 'Perodua','1152' : 'Peugeot','1157' : 'Plymouth','2240' : 'Polonez','1177' : 'Pontiac','1204' : 'Porsche','2248' : 'Proton','1215' : 'Renault','1223' : 'Rolls-Royce','2295' : 'Rover','2641' : 'SH Auto','1232' : 'Saab','2325' : 'Samand','1239' : 'Saturn','1261' : 'Scion','2327' : 'Seat','2343' : 'Shatenet','2345' : 'Simca','2357' : 'Skoda','2375' : 'Smart','2380' : 'Ssang Young','1268' : 'Subaru','1283' : 'Suzuki','2399' : 'Talbot','2408' : 'Tata','2414' : 'Tavria','2614' : 'Tempo','2418' : 'Terberg','2421' : 'Tesla','2425' : 'Tofas','1297' : 'Toyota','2455' : 'Trabant','1328' : 'Triumph','2595' : 'Uaz','2467' : 'Volga','2475' : 'Volvo','2517' : 'Vw','2547' : 'Warszawa','2550' : 'Wartburg','2555' : 'Wiesmann','2584' : 'Xinkai','2560' : 'Xinshun','2562' : 'Zastava','2570' : 'Zaz'},

					AlfaRomeo:{'145' : '145','146' : '146','147' : '147','155' : '155','156' : '156','159' : '159','164' : '164','166' : '166','33' : '33','75_al' : '75','90' : '90','Alfetta' : 'Alfetta','Brera' : 'Brera','Giulietta' : 'Giulietta','GTV' : 'GTV','MiTo' : 'MiTo','Spider' : 'Spider','Sprint' : 'Sprint','Sud' : 'Sud'},

					Acura:{'299' : 'Integra','301' : 'MDX','2842' : 'RDX','304' : 'RL','305' : 'RSX','306' : 'SLX','307' : 'TL','308' : 'TSX'},

					Aixam:{'400_ax' : '400','505_ax' : '505','600_ax' : '600'},

					Bmw:{'1' : '1','3' : '3','5' : '5','5 Grand Turismo' : '5 Grand Turismo','6' : '6','7' : '7','116' : '116','118' : '118','120_bmw' : '120','315' : '315','316' : '316','318' : '318','320_bmw' : '320','323_bmw' : '323','324' : '324','325' : '325','328' : '328','330_bmw' : '330','335' : '335','501_bmw' : '501','518' : '518','520' : '520','523' : '523','524' : '524','525' : '525','528' : '528','530' : '530','535' : '535','540' : '540','545' : '545','550' : '550','628' : '628','630' : '630','633' : '633','635' : '635','640' : '640','645' : '645','650' : '650','700' : '700','721' : '721','723' : '723','725' : '725','728' : '728','730' : '730','732' : '732','733' : '733','735' : '735','740_bmw' : '740','745' : '745','750_bmw' : '750','760_bmw' : '760','840' : '840','850_bmw' : '850','1500' : '1500','1600' : '1600','1602' : '1602','1800' : '1800','2000' : '2000','2002' : '2002','Izetta' : 'Izetta','M' : 'M','M3' : 'M3','M5' : 'M5','M6' : 'M6','X1' : 'X1','X3' : 'X3','X5' : 'X5','X6' : 'X6','Z1' : 'Z1','Z3' : 'Z3','Z4' : 'Z4','Z8' : 'Z8'},

					Berliner:{'Coupe' : 'Coupe'},

					Audi:{'50' : '50','60' : '60','80' : '80','90' : '90','100_audi' : '100','200' : '200','A1' : 'A1','A2' : 'A2','A3' : 'A3','A4' : 'A4','A5' : 'A5','A6' : 'A6','A7' : 'A7','A8' : 'A8','Allroad' : 'Allroad','Q3' : 'Q3','Q5' : 'Q5','Q7' : 'Q7','R8' : 'R8','RS 4' : 'RS 4','RS 5' : 'RS 5','RS 6' : 'RS 6','S2' : 'S2','S3' : 'S3','S4' : 'S4','S5' : 'S5','S6' : 'S6','S8' : 'S8','TT' : 'TT'},

					Bentley:{'Arnage' : 'Arnage','Azure' : 'Azure','Continental_bent' : 'Continental GT','Mulsanne' : 'Mulsanne', 'T1_b' : 'T-series'},

					Dacia:{'1100' : '1100','1300' : '1300','1304' : '1304','1307' : '1307','1310' : '1310','1350' : '1350','Duster' : 'Duster','Liberta' : 'Liberta','Logan' : 'Logan','Nova_dac' : 'Nova','Pickup_dacia' : 'Pickup','Sandero' : 'Sandero','Solenza' : 'Solenza'},

					Corvette:{'C06 Convertible' : 'C06 Convertible','C06 Coupe' : 'C06 Coupe','Powa' : 'Powa','Z06' : 'Z06','C4' : 'C4','C5' : 'C5'},

					Bugatti:{'Veyron' : 'Veyron'},

					Borgward:{'Hansa' : 'Hansa'},

					Buick:{'Electra' : 'Electra','Invicta' : 'Invicta','Park Avenue' : 'Park Avenue','Regal' : 'Regal','Rendezvous' : 'Rendezvous','Skylark' : 'Skylark','Skyline' : 'Skyline'},

					Cadillac:{'Allante' : 'Allante','BLS' : 'BLS','Brougham' : 'Brougham','CTS' : 'CTS','DeVille' : 'DeVille','Eldorado' : 'Eldorado','Escalade' : 'Escalade','Fleetwood' : 'Fleetwood','SRX' : 'SRX','STS' : 'STS','Seville' : 'Seville','XLR' : 'XLR'},

					Chevrolet:{'Alero' : 'Alero','Astro' : 'Astro','Avalanche' : 'Avalanche','Aveo' : 'Aveo','Beretta' : 'Beretta','Blazer' : 'Blazer','Camaro' : 'Camaro','Caprice' : 'Caprice','Captiva' : 'Captiva','Cavalier' : 'Cavalier','Citation' : 'Citation','Cobalt' : 'Cobalt','Colorado' : 'Colorado','Corvette' : 'Corvette','Cruze' : 'Cruze','Epica' : 'Epica','Equinox' : 'Equinox','Evanda' : 'Evanda','GMC' : 'GMC','HHR' : 'HHR','Impala' : 'Impala','Kalos_cr' : 'Kalos','Lacetti_cr' : 'Lacetti','Lumina' : 'Lumina','Malibu' : 'Malibu','Matiz_cr' : 'Matiz','Niva_cr' : 'Niva','Nova_cr' : 'Nova','Nubira_che' : 'Nubira','Orlando' : 'Orlando','SSR' : 'SSR','Silverado' : 'Silverado','Spark' : 'Spark','Suburban' : 'Suburban','Tacuma_cr' : 'Tacuma','Tahoe' : 'Tahoe','Tracker' : 'Tracker','Trailblazer' : 'Trailblazer','Transsport' : 'Transsport'},

					Chrysler:{'300C' : '300C','300M' : '300M','Crossfire' : 'Crossfire','Daytona_ch' : 'Daytona','Es' : 'Es','GTS' : 'GTS','Gr. Voyager' : 'Gr. Voyager','Intrepid' : 'Intrepid','LeBaron' : 'LeBaron','Neon_kr' : 'Neon','New Yorker' : 'New Yorker','PT Cruiser' : 'PT Cruiser','Pacifica' : 'Pacifica','Saratoga' : 'Saratoga','Sebring' : 'Sebring','Stratus_cr' : 'Stratus','Vision_cr' : 'Vision','Voyager' : 'Voyager','Wrangler' : 'Wrangler'},

					Citroen:{'2cv' : '2cv','Ax' : 'Ax','Berlingo' : 'Berlingo','Bx' : 'Bx','C-Crosser' : 'C-Crosser','C1' : 'C1','C15' : 'C15','C2' : 'C2','C3' : 'C3','C3 Picasso' : 'C3 Picasso','C4_s' : 'C4','C4 Picasso' : 'C4 Picasso','C5_s' : 'C5','C6_s' : 'C6','C8' : 'C8','Cx' : 'Cx','DS' : 'DS','DS3' : 'DS3','DS4' : 'DS4','Evasion' : 'Evasion','Nemo' : 'Nemo','Saxo' : 'Saxo','Visa' : 'Visa','Xantia' : 'Xantia','Xm' : 'Xm','Xsara' : 'Xsara','Xsara Picassa' : 'Xsara Picassa','Zx' : 'Zx'},

					Datsun:{'Bluebird_dat' : 'Bluebird','Cherry' : 'Cherry','Stanza' : 'Stanza'},

					DKW:{'F102' : 'F102'},

					Dodge:{'Avenger' : 'Avenger','Caliber' : 'Caliber','Caravan' : 'Caravan','Challenger' : 'Challenger','Charger' : 'Charger','Coronet' : 'Coronet','Dakota' : 'Dakota','Daytona' : 'Daytona','Durango' : 'Durango','Dynasty' : 'Dynasty','Interpid' : 'Interpid','Journey' : 'Journey','Magnum' : 'Magnum','Neon' : 'Neon','Nitro' : 'Nitro','Ram' : 'Ram','Ram' : 'Ram','Shadow' : 'Shadow','Stealth' : 'Stealth','Stratus' : 'Stratus','Viper' : 'Viper'},

					Ford:{'12m' : '12m','15m' : '15m','17m' : '17m','20m' : '20m','Aerostar' : 'Aerostar','Bronco' : 'Bronco','C-Max' : 'C-Max','Capri' : 'Capri','Connect' : 'Connect','Consul' : 'Consul','Contour' : 'Contour','Cortina' : 'Cortina','Cosworth' : 'Cosworth','Cougar' : 'Cougar','Courier' : 'Courier','Crown Victoria' : 'Crown Victoria','Econoline' : 'Econoline','Escape' : 'Escape','Escort' : 'Escort','Everest' : 'Everest','Excursion' : 'Excursion','Expedition' : 'Expedition','Explorer' : 'Explorer','F150' : 'F150','F150' : 'F150','F250' : 'F250','F350' : 'F350','F450' : 'F450','Fiesta' : 'Fiesta','Focus' : 'Focus','Focus C-Max' : 'Focus C-Max','Fusion' : 'Fusion','Galaxy' : 'Galaxy','Granada' : 'Granada','Ka' : 'Ka','Kuga' : 'Kuga','Maverick' : 'Maverick','Mondeo' : 'Mondeo','Mustang' : 'Mustang','Orion' : 'Orion','Probe' : 'Probe','Puma' : 'Puma','Ranger' : 'Ranger','S-Max' : 'S-Max','Scorpio' : 'Scorpio','Sierra' : 'Sierra','Sportka' : 'Sportka','Streetka' : 'Streetka','Taunus' : 'Taunus','Taurus' : 'Taurus','Thunderbird' : 'Thunderbird','Windstar' : 'Windstar','Zephyr' : 'Zephyr'},

					FSO:{'Polonez' : 'Polonez'},

					Eagle:{'Premier' : 'Premier','Talon' : 'Talon','Vision' : 'Vision'},

					Ferrari:{'348' : '348','360 Modena' : '360 Modena','360 Spider' : '360 Spider','458 Italia' : '458 Italia','599' : '599','California' : 'California','Enzo' : 'Enzo','F430' : 'F430','F456m' : 'F456m','F575m Maranello' : 'F575m Maranello','F612 Scaglietti' : 'F612 Scaglietti','Mondial 8' : 'Mondial 8','Testarossa' : 'Testarossa'},

					Fiat:{'124' : '124','125_fiat' : '125','126_fiat' : '126','127' : '127','128' : '128','131' : '131','132' : '132','150' : '150','500_fiat' : '500','600_fiat' : '600','650' : '650','750' : '750','1100' : '1100','1400' : '1400','1800' : '1800','Albea' : 'Albea','Argenta' : 'Argenta','Barchetta' : 'Barchetta','Bertone' : 'Bertone','Brava' : 'Brava','Bravo' : 'Bravo','Cinquecento' : 'Cinquecento','Coupe_fiat' : 'Coupe','Croma' : 'Croma','Doblo' : 'Doblo','Duna' : 'Duna','Fiorino' : 'Fiorino','Idea' : 'Idea','Linea' : 'Linea','Marea' : 'Marea','Multipla' : 'Multipla','Palio' : 'Palio','Panda' : 'Panda','Punto' : 'Punto','Regata' : 'Regata','Ritmo' : 'Ritmo','Scudo' : 'Scudo','Sedici' : 'Sedici','Seicento' : 'Seicento','Siena' : 'Siena','Stilo' : 'Stilo','Strada' : 'Strada','Tempra' : 'Tempra','Tipo' : 'Tipo','Topolino' : 'Topolino','Ulysse' : 'Ulysse','Uno' : 'Uno'},

					Geo:{'Metro' : 'Metro','Prizm' : 'Prizm','Storm' : 'Storm','Tracker' : 'Tracker'},

					IFA:{'F9' : 'F9'},

					Honda:{'Accord' : 'Accord','CR-V' : 'CR-V','CRX' : 'CRX','CRZ_honda' : 'CRZ','City' : 'City','Civic' : 'Civic','Civic Ballade' : 'Civic Ballade','Concerto' : 'Concerto','Cr-V' : 'Cr-V','Element' : 'Element','FR-V' : 'FR-V','Fit' : 'Fit','HR-V' : 'HR-V','HR-V' : 'HR-V','Insight' : 'Insight','Integra' : 'Integra','Jazz' : 'Jazz','Legend' : 'Legend','Logo' : 'Logo','NSX' : 'NSX','Odyssey' : 'Odyssey','Passport' : 'Passport','Prelude' : 'Prelude','Quintet' : 'Quintet','Ridgeline' : 'Ridgeline','S2000' : 'S2000','Shuttle' : 'Shuttle','Stream' : 'Stream'},

					Daimler:{'Accent' : 'Accent','Atos' : 'Atos','Coupe' : 'Coupe','Elantra' : 'Elantra','Excel' : 'Excel','Galloper' : 'Galloper','Genesis' : 'Genesis','Getz' : 'Getz','Grace' : 'Grace','Grandeur' : 'Grandeur','Ix35' : 'Ix35','Ix55' : 'Ix55','Lantra' : 'Lantra','Matrix' : 'Matrix','Pony' : 'Pony','Porter' : 'Porter','S' : 'S','Santa Fe' : 'Santa Fe','Santamo' : 'Santamo','Sonata' : 'Sonata','Stelar' : 'Stelar','Tb' : 'Tb','Terracan' : 'Terracan','Trajet' : 'Trajet','Tucson' : 'Tucson','Xg' : 'Xg','i10' : 'i10','i20' : 'i20','i30' : 'i30','i40' : 'i40','ix20' : 'ix20'},

					Innocenti:{'Mini' : 'Mini'},

					Jaguar:{'Daimler' : 'Daimler','Daimler Double Six' : 'Daimler Double Six','Daimler Six' : 'Daimler Six','S-Type' : 'S-Type','Sovereign' : 'Sovereign','Super V8' : 'Super V8','X-Type' : 'X-Type','XF' : 'XF','XJ' : 'XJ','XJR' : 'XJR','XJS' : 'XJS','XJSC' : 'XJSC','XK8' : 'XK8','XKR' : 'XKR'},

					Lada:{'1200_lada' : '1200','1300_lada' : '1300','1500_lada' : '1500','1600_lada' : '1600','2101' : '2101','2102' : '2102','2103' : '2103','2104' : '2104','2105' : '2105','2106' : '2106','2107' : '2107','2108' : '2108','2109' : '2109','2110' : '2110','21011' : '21011','21012' : '21012','21013' : '21013','21015' : '21015','21043' : '21043','21051' : '21051','21053' : '21053','21061' : '21061','21063' : '21063','21074' : '21074','21083' : '21083','21093' : '21093','21099' : '21099','21213' : '21213','Kalina' : 'Kalina','Niva' : 'Niva','Nova' : 'Nova','Oka' : 'Oka','Priora' : 'Priora','Samara' : 'Samara'},

					Kia:{'Avella Delta' : 'Avella Delta','Carens' : 'Carens','Carnival' : 'Carnival','Ceed' : 'Ceed','Cerato' : 'Cerato','Clarus' : 'Clarus','Joecs' : 'Joecs','Joyce' : 'Joyce','Magentis' : 'Magentis','Mohave' : 'Mohave','Opirus' : 'Opirus','Picanto' : 'Picanto','Pride' : 'Pride','Retona' : 'Retona','Rio' : 'Rio','Sephia' : 'Sephia','Shuma' : 'Shuma','Sorento' : 'Sorento','Soul' : 'Soul','Sportage' : 'Sportage','Venga' : 'Venga'},

					Lamborghini:{'Countach' : 'Countach','Diablo' : 'Diablo','Gallardo' : 'Gallardo','Murcielago' : 'Murcielago','Reventon' : 'Reventon'},

					Lancia:{'A112' : 'A112','Aurelia' : 'Aurelia','Beta' : 'Beta','Dedra' : 'Dedra','Delta' : 'Delta','Kappa' : 'Kappa','Lybra' : 'Lybra','Musa' : 'Musa','Phedra' : 'Phedra','Prisma' : 'Prisma','Thema' : 'Thema','Thesis' : 'Thesis','Unior' : 'Unior','Y' : 'Y','Y10' : 'Y10','Ypsilon' : 'Ypsilon','Zeta' : 'Zeta'},

					Lexus:{'ES' : 'ES','IS' : 'IS','LX' : 'LX','RX_lex' : 'RX','RX 300' : 'RX 300','RX 350' : 'RX 350','RX 400h' : 'RX 400h','RX 450' : 'RX 450','SC' : 'SC'},

					Lincoln:{'Continental' : 'Continental','LS' : 'LS','MKX' : 'MKX','MKZ' : 'MKZ','Mark' : 'Mark','Mark LT' : 'Mark LT','Mark it' : 'Mark it','Navigator' : 'Navigator','Town Car' : 'Town Car','Zephyr' : 'Zephyr'},

					Lotus:{'Elise' : 'Elise','Europa' : 'Europa','Evora' : 'Evora','Exige' : 'Exige','Elan' : 'Elan'},

					Maserati:{'Biturbo' : 'Biturbo','GranCabrio' : 'GranCabrio','GranTurismo' : 'GranTurismo','Quattroporte' : 'Quattroporte'},

					Maybach:{'57' : '57','62' : '62'},

					Moskvich:{'1360' : '1360','1361' : '1361','1500' : '1500','2136' : '2136','2138' : '2138','2140' : '2140','2141' : '2141','21412' : '21412','21417' : '21417','2142' : '2142','2715' : '2715','403' : '403','407_mosk' : '407','408' : '408','412' : '412','426' : '426','427_mosk' : '427','503_mosk' : '503','Aleko' : 'Aleko','ijj' : 'Р�Р–'},

					Morgan:{'Aero 8' : 'Aero 8'},

					Mercury:{'Marauder' : 'Marauder','Milan' : 'Milan','Monarch' : 'Monarch','Mountaineer' : 'Mountaineer','Villager' : 'Villager'},

					MG:{'MGA' : 'MGA','MGB' : 'MGB','MGF' : 'MGF','TF' : 'TF','ZR' : 'ZR','ZS' : 'ZS','ZT' : 'ZT','ZT-T' : 'ZT-T'},

					Mitsubishi:{'3000GT' : '3000GT','Carisma' : 'Carisma','Colt' : 'Colt','Cordia' : 'Cordia','Eclipse' : 'Eclipse','Galant' : 'Galant','Grandis' : 'Grandis','L200' : 'L200','Lancer' : 'Lancer','Montero' : 'Montero','Outlander' : 'Outlander','Pajero' : 'Pajero','PajeroPinin' : 'Pajero Pinin','Pajero Sport' : 'Pajero Sport','Sapporo' : 'Sapporo','Sigma' : 'Sigma','Space Gear' : 'Space Gear','Space Runner' : 'Space Runner','Space Star' : 'Space Star','Space Wagon' : 'Space Wagon','Stration' : 'Stration','Trebia' : 'Trebia'},

					Oldsmobile:{'Achieva' : 'Achieva','Alero' : 'Alero','Aurora' : 'Aurora','Bravada' : 'Bravada','Cutlass' : 'Cutlass','Firenza' : 'Firenza','Intrigue' : 'Intrigue','Regency' : 'Regency','Silhouette' : 'Silhouette','Toronado' : 'Toronado'},

					Opel:{'Admiral' : 'Admiral','Agila' : 'Agila','Antara' : 'Antara','Ascona' : 'Ascona','Astra' : 'Astra','Calibra' : 'Calibra','Campo' : 'Campo','Combo' : 'Combo','Commodore' : 'Commodore','Corsa' : 'Corsa','Diplomat' : 'Diplomat','Frontera' : 'Frontera','GT_opel' : 'GT','Insignia' : 'Insignia','Kadett' : 'Kadett','Kapitaen' : 'Kapitaen','Manta' : 'Manta','Meriva' : 'Meriva','Monterey' : 'Monterey','Monza' : 'Monza','Omega' : 'Omega','Record' : 'Record','Senator' : 'Senator','Signum' : 'Signum','Sintra' : 'Sintra','Speedster' : 'Speedster','Tigra' : 'Tigra','Vectra' : 'Vectra','Zafira' : 'Zafira'},

					Plymouth:{'Acclaim' : 'Acclaim','Barracuda' : 'Barracuda','Breeze' : 'Breeze','Colt_ply' : 'Colt','Horizon' : 'Horizon','Laser' : 'Laser','Neon_ply' : 'Neon','Prowler' : 'Prowler','Reliant' : 'Reliant','Road Runner' : 'Road Runner','Sundance' : 'Sundance','Volare' : 'Volare','Voyager_ply' : 'Voyager'},

					Polonez:{'Pickup' : 'Pickup'},

					Pontiac:{'Aztek' : 'Aztek','Bonneville' : 'Bonneville','Catalina' : 'Catalina','Fiero' : 'Fiero','Firebird' : 'Firebird','Grand Am' : 'Grand Am','Grand Prix' : 'Grand Prix','GTO' : 'GTO','Le Mans' : 'Le Mans','Solstice' : 'Solstice','Sunbird' : 'Sunbird','Sunfire' : 'Sunfire','Tempest' : 'Tempest','Trans Am' : 'Trans Am','Trans Sport' : 'Trans Sport','Vibe' : 'Vibe'},

					Proton:{'400' : '400','Persone' : 'Persone','Satria' : 'Satria'},

					Porsche:{'911' : '911','924' : '924','928' : '928','935' : '935','944' : '944','956' : '956','968' : '968','993' : '993','996' : '996','Boxster' : 'Boxster','Carrera' : 'Carrera','Cayenne' : 'Cayenne','Cayman' : 'Cayman','Panamera' : 'Panamera'},

					Renault:{'4' : '4','5_ren' : '5','8' : '8','9' : '9','10' : '10','11' : '11','12' : '12','14' : '14','16' : '16','18' : '18','19' : '19','20' : '20','21' : '21','25_ren' : '25','29' : '29','30' : '30','Alpine' : 'Alpine','Avantime' : 'Avantime','Bakara' : 'Bakara','Bulgar' : 'Bulgar','Chamade' : 'Chamade','Clio' : 'Clio','Espace' : 'Espace','Express' : 'Express','Fluence' : 'Fluence','Fuego' : 'Fuego','Grand Espace' : 'Grand Espace','Grand Scenic' : 'Grand Scenic','Kangoo' : 'Kangoo','Koleos' : 'Koleos','Laguna' : 'Laguna','Laguna Coupe' : 'Laguna Coupe','Latitude' : 'Latitude','Megane' : 'Megane','Modus' : 'Modus','Nevada' : 'Nevada','Rapid_ren' : 'Rapid','Safrane' : 'Safrane','Scenic' : 'Scenic','Symbol' : 'Symbol','Twingo' : 'Twingo','Vel Statis' : 'Vel Statis'},

					Rover:{'111_ro' : '111','114' : '114','200' : '200','213' : '213','216' : '216','220' : '220','25' : '25','400' : '400','414' : '414','416' : '416','418' : '418','420' : '420','45' : '45','600_ro' : '600','618' : '618','620' : '620','623' : '623','75' : '75','800' : '800','820' : '820','825' : '825','827' : '827','City' : 'City','Estate' : 'Estate','Maestro' : 'Maestro','Metro' : 'Metro','Mini' : 'Mini','Montego' : 'Montego','Streetwise' : 'Streetwise'},

					Samand:{'LX' : 'LX'},

					Saab:{'9-3' : '9-3','9-4x' : '9-4x','9-5' : '9-5','9-7x' : '9-7x','900' : '900','9000' : '9000'},

					Seat:{'Alhambra' : 'Alhambra','Altea' : 'Altea','Arosa' : 'Arosa','Cordoba' : 'Cordoba','Exeo' : 'Exeo','Fura' : 'Fura','Ibiza' : 'Ibiza','Inka' : 'Inka','Leon' : 'Leon','Malada' : 'Malada','Marbella' : 'Marbella','Ronda' : 'Ronda','Terra' : 'Terra','Toledo' : 'Toledo','Vario' : 'Vario'},

					Scion:{'tC' : 'tC','xA' : 'xA','xB' : 'xB'},

					Simca:{'1307' : '1307','1308' : '1308','1309' : '1309','1510' : '1510','Aront' : 'Aront','Chrysler' : 'Chrysler','Horizon' : 'Horizon','Shambord' : 'Shambord','Solara' : 'Solara','Special' : 'Special','Versail' : 'Versail'},

					Subaru:{'1800' : '1800','B9 Tribeca' : 'B9 Tribeca','Baja' : 'Baja','E12' : 'E12','Forester' : 'Forester','Impreza' : 'Impreza','Justy' : 'Justy','Legacy' : 'Legacy','Libero' : 'Libero','Outback' : 'Outback','SVX' : 'SVX'},

					Suzuki:{'Alto' : 'Alto','Baleno' : 'Baleno','Forenza' : 'Forenza','Grand Vitara' : 'Grand Vitara','Ignus' : 'Ignis','Jimmy_s' : 'Jimmy','Liana' : 'Liana','Maruti' : 'Maruti','Reno' : 'Reno','SX4' : 'SX4','Samurai' : 'Samurai','Sj' : 'Sj','Splash' : 'Splash','Swift' : 'Swift','Vitara' : 'Vitara','Wagon R' : 'Wagon R','X-90' : 'X-90','XL-7' : 'XL-7'},

					Trabant:{'600_tr' : '600','601' : '601','Combi' : 'Combi','T 1.1' : 'T 1.1'},

					Triumph:{'Acclaim' : 'Acclaim','Dolomite' : 'Dolomite','Herald' : 'Herald','Spitfire' : 'Spitfire','Stag' : 'Stag','TR6' : 'TR6','TR7' : 'TR7'},

					Wartburg:{'1.3' : '1.3','311' : '311','312' : '312','353' : '353'},

					Warszawa:{'223' : '223','232' : '232'},

					AstonMartin:{'DBS' : 'DBS','DB9' : 'DB9','Vanquish' : 'Vanquish'},

					Perodua:{'Kancil' : 'Kancil','Kelisa' : 'Kelisa','Kembara' : 'Kembara','Kenari' : 'Kenari','Nippa' : 'Nippa','Rusa' : 'Rusa'},

					Daihatsu:{'Applause' : 'Applause','Charade' : 'Charade','Charmant' : 'Charmant','Copen' : 'Copen','Cuore' : 'Cuore','Feroza' : 'Feroza','Gran Move' : 'Gran Move','Hijet' : 'Hijet','Materia' : 'Materia','Move' : 'Move','Rocky' : 'Rocky','Sharade' : 'Sharade','Sirion' : 'Sirion','Taft' : 'Taft','Terios' : 'Terios','Wildcat' : 'Wildcat','Yrv' : 'Yrv'},

					Hyundai:{'Accent' : 'Accent','Atos' : 'Atos','Coupe' : 'Coupe','Elantra' : 'Elantra','Galloper' : 'Galloper','Getz' : 'Getz','Grandeur' : 'Grandeur','H 100' : 'H 100','H-1' : 'H-1','H-1 Starex' : 'H-1 Starex','i10' : 'i10','i20' : 'i20','i30' : 'i30','i30 CW' : 'i30 CW','i40' : 'i40','ix35' : 'ix35','ix55' : 'ix55','Lantra' : 'Lantra','Matrix' : 'Matrix','Pony' : 'Pony','S-Coupe' : 'S-Coupe','Santa Fe' : 'Santa Fe','Santamo' : 'Santamo','Sonata' : 'Sonata','Terracan' : 'Terracan','Trajet' : 'Trajet','Tucson' : 'Tucson','Veloster' : 'Veloster','XG_hyun' : 'XG'},

					Matra:{'Murena' : 'Murena','Rancho' : 'Rancho'},

					Mazda:{'2' : '2','3_m' : '3','5_m' : '5','6_m' : '6','121' : '121','323' : '323','626' : '626','929' : '929','CX-7' : 'CX-7','CX-9' : 'CX-9','Demio' : 'Demio','MX-3' : 'MX-3','MX-5' : 'MX-5','MX-6' : 'MX-6','Mpv' : 'Mpv','Premacy' : 'Premacy','RX-7' : 'RX-7','RX-8' : 'RX-8','Tribute' : 'Tribute','Tribute' : 'Tribute','Xedos' : 'Xedos'},

					Mercedes:{'110' : '110','111' : '111','113' : '113','114' : '114','115' : '115','116' : '116','123' : '123','124' : '124','126' : '126','150' : '150','170' : '170','180' : '180','190' : '190','200_m' : '200','220_m' : '220','230' : '230','240_mer' : '240','250' : '250','260' : '260','280' : '280','290' : '290','300' : '300','320' : '320','350' : '350','380' : '380','380SE' : '380SE','420' : '420','450' : '450','500' : '500','560' : '560','600' : '600','A140' : 'A140','A150' : 'A150','A160' : 'A160','A170' : 'A170','A180' : 'A180','A190' : 'A190','A200' : 'A200','A210' : 'A210','Adenauer' : 'Adenauer','B150' : 'B150','B170' : 'B170','B180' : 'B180','B200' : 'B200','C180' : 'C180','C200' : 'C200','C220' : 'C220','C230' : 'C230','C240' : 'C240','C250' : 'C250','C270' : 'C270','C280' : 'C280','C320' : 'C320','C350' : 'C350','C55 AMG' : 'C55 AMG','CL' : 'CL','CLK' : 'CLK','CLS 320' : 'CLS 320','CLS 350' : 'CLS 350','CLS 55' : 'CLS 55','CLS 63' : 'CLS 63','E200' : 'E200','E220' : 'E220','E230' : 'E230','E240' : 'E240','E250' : 'E250','E260' : 'E260','E270' : 'E270','E280' : 'E280','E290' : 'E290','E300' : 'E300','E320' : 'E320','E350' : 'E350','E400' : 'E400','E420' : 'E420','E500' : 'E500','E55' : 'E55','E60' : 'E60','E63' : 'E63','G_all' : 'G','G350' : 'G350','G400' : 'G400','Gl' : 'GL','Glk' : 'GLK','Ml' : 'ML','R' : 'R','R280' : 'R280','R300' : 'R300','R320' : 'R320','R350' : 'R350','R500' : 'R500','R63' : 'R63','S' : 'S','S250' : 'S250','S280' : 'S280','S300' : 'S300','S320' : 'S320','S350' : 'S350','S400' : 'S400','S420' : 'S420','S450' : 'S450','S500' : 'S500','S55' : 'S55','S600' : 'S600','S63' : 'S63','S65' : 'S65','SL' : 'SL','SLK' : 'SLK','SLR' : 'SLR','SLS' : 'SLS','Smart' : 'Smart','V230' : 'V230','Vaneo' : 'Vaneo'},

					Mini:{'Clubman' : 'Clubman','Cooper' : 'Cooper','Cooper Cabrio' : 'Cooper Cabrio','Cooper S' : 'Cooper S','Cooper S Cabrio' : 'Cooper S Cabrio','Countryman' : 'Countryman','One' : 'One'},

					Nissan:{'100NX' : '100NX','200SX' : '200SX','350Z' : '350Z','370Z' : '370Z','Almera' : 'Almera','Almera Tino' : 'Almera Tino','Altima' : 'Altima','Bluebird' : 'Bluebird','Cedric' : 'Cedric','Cherry' : 'Cherry','Frontier' : 'Frontier','GT-R' : 'GT-R','Juke' : 'Juke','Laurel' : 'Laurel','Maxima' : 'Maxima','Micra' : 'Micra','Murano' : 'Murano','NP300' : 'NP300','Navara' : 'Navara','Note' : 'Note','Pathfinder' : 'Pathfinder','Patrol' : 'Patrol','Pickup' : 'Pickup','Pixo' : 'Pixo','Prairie' : 'Prairie','Primera' : 'Primera','Qashwai' : 'Qashwai','Rogue' : 'Rogue','Serena' : 'Serena','Silvia' : 'Silvia','Skyline' : 'Skyline','Stantza' : 'Stantza','Sunny' : 'Sunny','Terrano' : 'Terrano','Tiida' : 'Tiida','Titan' : 'Titan','Versa' : 'Versa','X-Trail' : 'X-Trail','Xterra' : 'Xterra'},

					Peugeot:{'104' : '104','106' : '106','107' : '107','202' : '202','204' : '204','205' : '205','206' : '206','207' : '207','304' : '304','305' : '305','306' : '306','307' : '307','308' : '308','309' : '309','402' : '402','403' : '403','404' : '404','405' : '405','406' : '406','407' : '407','504' : '504','505' : '505','508' : '508','604' : '604','605' : '605','607' : '607','806' : '806','807' : '807','1007' : '1007','3008' : '3008','4007' : '4007','5008' : '5008','Bipper' : 'Bipper','Partner' : 'Partner','RCZ' : 'RCZ','Range' : 'Range'},

					Saturn:{'Astra' : 'Astra','Aura' : 'Aura','Outlook' : 'Outlook','Sky' : 'Sky','Vue' : 'Vue'},

					Vw:{'1200' : '1200','1300' : '1300','1302' : '1302','1303' : '1303','1500' : '1500','1600' : '1600','Amarok' : 'Amarok','Bora' : 'Bora','Caddy' : 'Caddy','Corrado' : 'Corrado','Derby' : 'Derby','Eos' : 'Eos','Fox' : 'Fox','Golf' : 'Golf','Jetta' : 'Jetta','Karman-Ghia' : 'Karman-Ghia','Lupo' : 'Lupo','Multivan' : 'Multivan','New Beetle' : 'New Beetle','Passat' : 'Passat','Phaeton' : 'Phaeton','Polo' : 'Polo','Rabbit' : 'Rabbit','Santana' : 'Santana','Sirocco' : 'Sirocco','Sharan' : 'Sharan','Taro' : 'Taro','Tiguan' : 'Tiguan','Touran' : 'Touran','Touareg' : 'Touareg','Vento' : 'Vento'},

					Volvo:{'142' : '142','144' : '144','145' : '145','164' : '164','1800 SE' : '1800 SE','240' : '240','244' : '244','245' : '245','262 C' : '262 C','264' : '264','340' : '340','343' : '343','344' : '344','345' : '345','360_vol' : '360','440' : '440','460' : '460','480' : '480','66' : '66','740' : '740','744' : '744','745' : '745','760' : '760','765' : '765','770' : '770','780' : '780','850' : '850','940' : '940','960' : '960','C30' : 'C30','C70' : 'C70','P1800' : 'P1800','S40' : 'S40','S60' : 'S60','S70' : 'S70','S80' : 'S80','V40' : 'V40','V50' : 'V50','V60' : 'V60','V70' : 'V70','XC70' : 'XC70','XC60' : 'XC60','XC90' : 'XC90'},

					Daewoo:{'Ace' : 'Ace','Chairman' : 'Chairman','Cielo' : 'Cielo','Espero' : 'Espero','Evanda' : 'Evanda','Fso' : 'Fso','Kalos' : 'Kalos','Korando_daew' : 'Korando','Lacetti' : 'Lacetti','Lanos' : 'Lanos','Leganza' : 'Leganza','Magnus' : 'Magnus','Matiz' : 'Matiz','Musso' : 'Musso','Nexia' : 'Nexia','Nubira' : 'Nubira','Prince' : 'Prince','Racer' : 'Racer','Rezzo' : 'Rezzo','Super' : 'Super','Tacuma' : 'Tacuma','Tico' : 'Tico'},

					PGO:{'Cevennes' : 'Cevennes','Speedster' : 'Speedster'},

					Shatenet:{'Stella' : 'Stella'},

					Skoda:{'100' : '100','1000' : '1000','105' : '105','120' : '120','125' : '125','130_skoda' : '130','135' : '135','136' : '136','Fabia' : 'Fabia','Favorit' : 'Favorit','Felicia' : 'Felicia','Forman' : 'Forman','Octavia' : 'Octavia','Rapid' : 'Rapid','Roomster' : 'Roomster','SuperB' : 'SuperB','Yeti' : 'Yeti'},

					Smart:{'Forfour' : 'Forfour','Fortwo' : 'Fortwo','MC' : 'MC','Roadster' : 'Roadster'},

					Talbot:{'1100' : '1100','1310' : '1310','Horizon' : 'Horizon','Matra' : 'Matra','Murena' : 'Murena','Samba' : 'Samba','Simka' : 'Simka','Solara' : 'Solara'},

					Tata:{'Aria' : 'Aria','Estate' : 'Estate','Indica' : 'Indica','Mint' : 'Mint','Nano' : 'Nano','Safari' : 'Safari','Sierra' : 'Sierra','Sumo' : 'Sumo','Telcoline' : 'Telcoline'},

					Tavria:{'Dana' : 'Dana','Kombi' : 'Kombi','Slavuta' : 'Slavuta'},

					Terberg:{'FL 2850' : 'FL 2850','SL 3000' : 'SL 3000'},

					Tesla:{'Model S' : 'Model S','Roadster' : 'Roadster','Roadster Sport' : 'Roadster Sport'},

					Tofas:{'Dogan' : 'Dogan','Karfal' : 'Karfal','Sahin' : 'Sahin'},

					Volga:{'22' : '22','24' : '24','3110' : '3110','3111' : '3111','M20' : 'M20','M21' : 'M21','Siber' : 'Siber'},

					Wiesmann:{'GT_wi' : 'GT','MF3' : 'MF3','MF4' : 'MF4','MF5' : 'MF5'},

					Xinshun:{'XS-D055' : 'XS-D055'},

					Zastava:{'600' : '600','750' : '750','Florida' : 'Florida','GT55' : 'GT55','Koral' : 'Koral','Miami' : 'Miami','Yugo45' : 'Yugo45'},

					Zaz:{'1102' : '1102','1103' : '1103','1105' : '1105','965' : '965','966' : '966','968' : '968','Tavria' : 'Tavria'},

					Xinkai:{'1021d' : '1021d','1021sl' : '1021sl','1021s' : '1021s','2021d' : '2021d','2021s' : '2021s'},

					Uaz:{'452' : '452','460' : '460','469_uaz' : '469','669' : '669','69' : '69','Hunter' : 'Hunter','Patriot' : 'Patriot'},

					Toyota:{'4runner' : '4runner','Auris' : 'Auris','Avalon' : 'Avalon','Avensis' : 'Avensis','Aygo' : 'Aygo','Camry' : 'Camry','Carina' : 'Carina','Celica' : 'Celica','Corolla' : 'Corolla','Corolla Verso' : 'Corolla Verso','Cressida' : 'Cressida','Crown' : 'Crown','Fj Cruiser' : 'Fj Cruiser','Highlander' : 'Highlander','Hilux' : 'Hilux','IQ' : 'IQ','Land Cruiser' : 'Land Cruiser','Matrix' : 'Matrix','MR2' : 'MR2','Paseo' : 'Paseo','Picnic' : 'Picnic','Previa' : 'Previa','Prius' : 'Prius','Rav4' : 'Rav4','Scion' : 'Scion','Sequoia' : 'Sequoia','Starlet' : 'Starlet','Supra' : 'Supra','Tacoma' : 'Tacoma','Tercel' : 'Tercel','Tundra' : 'Tundra','Verso' : 'Verso','Venza' : 'Venza','Urban Cruiser' : 'Urban Cruiser','Yaris' : 'Yaris'},

					Tempo:{'Gurkha' : 'Gurkha','Judo' : 'Judo','Traveller' : 'Traveller'},

					SsangYoung:{'Actyon' : 'Actyon','Actyon Sport' : 'Actyon Sport','Chairman' : 'Chairman','Korando' : 'Korando','Kyron' : 'Kyron','Musso' : 'Musso','Rextox' : 'Rextox','Rodius' : 'Rodius'},

					SHAuto:{'CEO' : 'CEO'},

					Mahindra:{'Armada' : 'Armada','Bolero' : 'Bolero','CL' : 'CL','Comander' : 'Comander','Goa' : 'Goa','Marshall' : 'Marshall','Scorpio' : 'Scorpio'},

					Landwind:{'JX6476da' : 'JX6476da'},

					LandRover:{'Defender' : 'Defender','Discovery' : 'Discovery','Freelander' : 'Freelander','Range Rover' : 'Range Rover'},

					Laforza:{'Magnum' : 'Magnum'},

					Jpx:{'Montez' : 'Montez'},

					Jeep:{'Cherokee' : 'Cherokee','Comander' : 'Comander','Compass' : 'Compass','Grand Cherokee' : 'Grand Cherokee','Patriot' : 'Patriot','Wrangler_j' : 'Wrangler'},

					Isuzu:{'Campo' : 'Campo', 'D-Max' : 'D-Max', 'Midi' : 'Midi', 'Rodeo' : 'Rodeo', 'Trooper' : 'Trooper', 'Gemini' : 'Gemini', 'Piazza' : 'Piazza', 'Pickup' : 'Pickup'},

					Infiniti:{'EX_inf' : 'EX', 'FX_inf' : 'FX', 'G35' : 'G35', 'G37' : 'G37', 'Minf' : 'M', 'QX56' : 'QX56', 'Fx45' : 'Fx45', 'G_inf' : 'G', 'G coupe' : 'G coupe', 'I' : 'I', 'J' : 'J', 'Q' : 'Q'},

					Hummer:{'H1' : 'H1','H2' : 'H2','H3' : 'H3'},

					GreatWall:{'Hover Cuv' : 'Hover Cuv','Safe' : 'Safe'},

					GMC:{'Envoy' : 'Envoy','Jimmy' : 'Jimmy','Saturn' : 'Saturn','Savana' : 'Savana','Sonama' : 'Sonama','Tracker' : 'Tracker','Typhoon' : 'Typhoon','Yukon' : 'Yukon'},

					Gaz:{'469' : '469','69_gaz' : '69'},

					Bertone:{'Freeclimber' : 'Freeclimber'},

					Asia:{'Rocsta' : 'Rocsta'},

					Aro:{'10' : '10','24' : '24','242' : '242','243' : '243','244' : '244','246' : '246','32' : '32','320' : '320','234' : '234','328' : '328','3' : '3'}

				};



		var fieldId = 'MakeModel';

		document.globalTreeControlRegistry.bindTreeData(fieldId, treeData);

		$("select[name^='MakeModel\[']").each(function()

		{

			document.globalTreeControlRegistry.bindControl(fieldId, this);

		});

	});

</script>
            <td><select name="MakeModel[tree][1]" style="margin-left:38px;">
                <option value="">Model</option>
                <option value=""  ></option>
              </select></td>
                 
            <td> 
              <select class="searchList"  name="region" style="margin-left:20px;">
                <option value="">Sity</option>
                <option value="Dubai">Dubai</option>
                <option value="Abu Dhabi">Abu Dhabi</option>
                <option value="Sharjah">Sharjah</option>
                <option value="Ras Al Khaimah">Ras Al Khaimah</option>
                <option value="Ajman">Ajman</option>
                <option value="Al Ain">Al Ain</option>
                <option value="Fujairah">Fujairah</option>
                <option value="Umm al-Quwain">Umm al-Quwain</option>
              </select></td>
     
          </tr>
          <!--
    <tr>
      <td><select name="oblast">
          <option value="">Област</option>
          <option value="Благоевград">Благоевград</option>
          <option value="Бургас">Бургас</option>
          <option value="Варна">Варна</option>
          <option value="Велико Търново">Велико Търново</option>
          <option value="Видин">Видин</option>
          <option value="Враца">Враца</option>
          <option value="Габрово">Габрово</option>
          <option value="Добрич">Добрич</option>
          <option value="Дупница">Дупница</option>
          <option value="Кърджали">Кърджали</option>
          <option value="Кюстендил">Кюстендил</option>
          <option value="Ловеч">Ловеч</option>
          <option value="Монтана">Монтана</option>
          <option value="Пазарджик">Пазарджик</option>
          <option value="Перник">Перник</option>
          <option value="Плевен">Плевен</option>
          <option value="Пловдив">Пловдив</option>
          <option value="Разград">Разград</option>
          <option value="Русе">Русе</option>
          <option value="Силистра">Силистра</option>
          <option value="Сливен">Сливен</option>
          <option value="Смолян">Смолян</option>
          <option value="София">София</option>
          <option value="Стара Загора">Стара Загора</option>
          <option value="Търговище">Търговище</option>
          <option value="Хасково">Хасково</option>
          <option value="Шумен">Шумен</option>
          <option value="Ямбол">Ямбол</option>
        </select></td>
    </tr> -->
          <tr>
            <td><b>Year:</b></td>
        
            <td>From: 
              <select name="Year_from" >
                <option value="">
                <option value="2014"  >2014 Г.</option>
                <option value="2013"  >2013 Г.</option>
                <option value="2012"  >2012 Г.</option>
                <option value="2011"  >2011 Г.</option>
                <option value="2010"  >2010 Г.</option>
                <option value="2009"  >2009 Г.</option>
                <option value="2008"  >2008 Г.</option>
                <option value="2007"  >2007 Г.</option>
                <option value="2006"  >2006 Г.</option>
                <option value="2005"  >2005 Г.</option>
                <option value="2004"  >2004 Г.</option>
                <option value="2003"  >2003 Г.</option>
                <option value="2002"  >2002 Г.</option>
                <option value="2001"  >2001 Г.</option>
                <option value="2000"  >2000 Г.</option>
                <option value="1999"  >1999 Г.</option>
                <option value="1998"  >1998 Г.</option>
                <option value="1997"  >1997 Г.</option>
                <option value="1996"  >1996 Г.</option>
                <option value="1995"  >1995 Г.</option>
                <option value="1994"  >1994 Г.</option>
                <option value="1993"  >1993 Г.</option>
                <option value="1992"  >1992 Г.</option>
                <option value="1991"  >1991 Г.</option>
                <option value="1990"  >1990 Г.</option>
                <option value="1989"  >1989 Г.</option>
                <option value="1988"  >1988 Г.</option>
                <option value="1987"  >1987 Г.</option>
                <option value="1986"  >1986 Г.</option>
                <option value="1985"  >1985 Г.</option>
                <option value="1984"  >1984 Г.</option>
                <option value="1983"  >1983 Г.</option>
                <option value="1982"  >1982 Г.</option>
                <option value="1981"  >1981 Г.</option>
                <option value="1980"  >1980 Г.</option>
                <option value="1979"  >1979 Г.</option>
                <option value="1978"  >1978 Г.</option>
                <option value="1977"  >1977 Г.</option>
                <option value="1976"  >1976 Г.</option>
                <option value="1975"  >1975 Г.</option>
                <option value="1974"  >1974 Г.</option>
                <option value="1973"  >1973 Г.</option>
                <option value="1972"  >1972 Г.</option>
                <option value="1971"  >1971 Г.</option>
                <option value="1970"  >1970 Г.</option>
                <option value="1969"  >1969 Г.</option>
                <option value="1968"  >1968 Г.</option>
                <option value="1967"  >1967 Г.</option>
                <option value="1966"  >1966 Г.</option>
                <option value="1965"  >1965 Г.</option>
                <option value="1964"  >1964 Г.</option>
                <option value="1963"  >1963 Г.</option>
                <option value="1962"  >1962 Г.</option>
                <option value="1961"  >1961 Г.</option>
                <option value="1960"  >1960 Г.</option>
                <option value="1959"  >1959 Г.</option>
                <option value="1958"  >1958 Г.</option>
                <option value="1957"  >1957 Г.</option>
                <option value="1956"  >1956 Г.</option>
                <option value="1955"  >1955 Г.</option>
                <option value="1954"  >1954 Г.</option>
                <option value="1953"  >1953 Г.</option>
                <option value="1952"  >1952 Г.</option>
                <option value="1951"  >1951 Г.</option>
                <option value="1950"  >1950 Г.</option>
                <option value="1949"  >1949 Г.</option>
                <option value="1948"  >1948 Г.</option>
                <option value="1947"  >1947 Г.</option>
                <option value="1946"  >1946 Г.</option>
                <option value="1945"  >1945 Г.</option>
                <option value="1944"  >1944 Г.</option>
                <option value="1943"  >1943 Г.</option>
                <option value="1942"  >1942 Г.</option>
                <option value="1941"  >1941 Г.</option>
                <option value="1940"  >1940 Г.</option>
                <option value="1939"  >1939 Г.</option>
                <option value="1938"  >1938 Г.</option>
                <option value="1937"  >1937 Г.</option>
                <option value="1936"  >1936 Г.</option>
                <option value="1935"  >1935 Г.</option>
                <option value="1934"  >1934 Г.</option>
                <option value="1933"  >1933 Г.</option>
                <option value="1932"  >1932 Г.</option>
                <option value="1931"  >1931 Г.</option>
                <option value="1930"  >1930 Г.</option>
              </select></td>
            <td>To: 
              <select name="Year_to">
                <option value="">
                <option value="2014"  >2014 Г.</option>
                <option value="2013"  >2013 Г.</option>
                <option value="2012"  >2012 Г.</option>
                <option value="2011"  >2011 Г.</option>
                <option value="2010"  >2010 Г.</option>
                <option value="2009"  >2009 Г.</option>
                <option value="2008"  >2008 Г.</option>
                <option value="2007"  >2007 Г.</option>
                <option value="2006"  >2006 Г.</option>
                <option value="2005"  >2005 Г.</option>
                <option value="2004"  >2004 Г.</option>
                <option value="2003"  >2003 Г.</option>
                <option value="2002"  >2002 Г.</option>
                <option value="2001"  >2001 Г.</option>
                <option value="2000"  >2000 Г.</option>
                <option value="1999"  >1999 Г.</option>
                <option value="1998"  >1998 Г.</option>
                <option value="1997"  >1997 Г.</option>
                <option value="1996"  >1996 Г.</option>
                <option value="1995"  >1995 Г.</option>
                <option value="1994"  >1994 Г.</option>
                <option value="1993"  >1993 Г.</option>
                <option value="1992"  >1992 Г.</option>
                <option value="1991"  >1991 Г.</option>
                <option value="1990"  >1990 Г.</option>
                <option value="1989"  >1989 Г.</option>
                <option value="1988"  >1988 Г.</option>
                <option value="1987"  >1987 Г.</option>
                <option value="1986"  >1986 Г.</option>
                <option value="1985"  >1985 Г.</option>
                <option value="1984"  >1984 Г.</option>
                <option value="1983"  >1983 Г.</option>
                <option value="1982"  >1982 Г.</option>
                <option value="1981"  >1981 Г.</option>
                <option value="1980"  >1980 Г.</option>
                <option value="1979"  >1979 Г.</option>
                <option value="1978"  >1978 Г.</option>
                <option value="1977"  >1977 Г.</option>
                <option value="1976"  >1976 Г.</option>
                <option value="1975"  >1975 Г.</option>
                <option value="1974"  >1974 Г.</option>
                <option value="1973"  >1973 Г.</option>
                <option value="1972"  >1972 Г.</option>
                <option value="1971"  >1971 Г.</option>
                <option value="1970"  >1970 Г.</option>
                <option value="1969"  >1969 Г.</option>
                <option value="1968"  >1968 Г.</option>
                <option value="1967"  >1967 Г.</option>
                <option value="1966"  >1966 Г.</option>
                <option value="1965"  >1965 Г.</option>
                <option value="1964"  >1964 Г.</option>
                <option value="1963"  >1963 Г.</option>
                <option value="1962"  >1962 Г.</option>
                <option value="1961"  >1961 Г.</option>
                <option value="1960"  >1960 Г.</option>
                <option value="1959"  >1959 Г.</option>
                <option value="1958"  >1958 Г.</option>
                <option value="1957"  >1957 Г.</option>
                <option value="1956"  >1956 Г.</option>
                <option value="1955"  >1955 Г.</option>
                <option value="1954"  >1954 Г.</option>
                <option value="1953"  >1953 Г.</option>
                <option value="1952"  >1952 Г.</option>
                <option value="1951"  >1951 Г.</option>
                <option value="1950"  >1950 Г.</option>
                <option value="1949"  >1949 Г.</option>
                <option value="1948"  >1948 Г.</option>
                <option value="1947"  >1947 Г.</option>
                <option value="1946"  >1946 Г.</option>
                <option value="1945"  >1945 Г.</option>
                <option value="1944"  >1944 Г.</option>
                <option value="1943"  >1943 Г.</option>
                <option value="1942"  >1942 Г.</option>
                <option value="1941"  >1941 Г.</option>
                <option value="1940"  >1940 Г.</option>
                <option value="1939"  >1939 Г.</option>
                <option value="1938"  >1938 Г.</option>
                <option value="1937"  >1937 Г.</option>
                <option value="1936"  >1936 Г.</option>
                <option value="1935"  >1935 Г.</option>
                <option value="1934"  >1934 Г.</option>
                <option value="1933"  >1933 Г.</option>
                <option value="1932"  >1932 Г.</option>
                <option value="1931"  >1931 Г.</option>
                <option value="1930"  >1930 Г.</option>
              </select></td>
          </tr>
          <tr>
            <td><b>Mileage</b></td>
         
            <td> From: 
              <select id="mileage_low" name="mileage_low" >
                <option value="" selected="selected">- Min -</option>
                <option value="0" >0</option>
                <option value="30000" >30000</option>
                <option value="50000" >50000</option>
                <option value="100000" >100000</option>
                <option value="150000">150000</option>
              </select></td>
            <td> To: 
              <select id="mileage_high" name="mileage_high">
                <option value="" selected="selected">- Max -</option>
                <option value="0" >0</option>
                <option value="30000" >30000</option>
                <option value="50000" >50000</option>
                <option value="100000" >100000</option>
                <option value="150000">150000</option>
              </select></td>
          </tr>
          <tr>
            <td><b>Price (AED):</b></td>
           
            <td> From:
              <input type=text name="Price_from"  value="" size="14" /></td>
            <td> To:
              <input type=text name="Price_to"  value=""  size="16"/></td>
          </tr>
          <tr>
            <td><b>Body Style:</b> </td>
            <td>
              <select class="searchList"  name="bodystyle" style="margin-left:40px;">
                <option value="">All</option>
                <option value="Saloon (Sedan)">Saloon(Sedan)</option>
                <option value="4x4">4x4</option>
                <option value="Hatchback">Hatchback</option>
                <option value="Convertible">Convertible</option>
                <option value="Coupe">Coupe</option>
                <option value="Pickup">Pickup</option>
                <option value="Station">Station</option>
                <option value="Van Minibus">Van Minibus</option>
                <option value="Caravan">Caravan</option>
              </select></td>
          </tr>

        </table>
        </td>
        </tr>
        <input type="submit" name="button" value="Search">
        </table>
      </form>
</div>
  <div id="results">
    <?php
if(isset($_GET['button'])) {
$mark=$_GET['MakeModel'];
$mark=$mark['tree'][0];
$model=$_GET['MakeModel'];
$model=$model['tree'][1];
$Price_from=$_GET['Price_from'];
$Price_to=$_GET['Price_to'];
$Year_from=$_GET['Year_from'];
$Year_to=$_GET['Year_to'];
$mileage_low=$_GET['mileage_low'];
$mileage_high=$_GET['mileage_high'];
$bodystyle=$_GET['bodystyle'];
$region=$_GET['region'];

if(!isset($_GET['page2'])) { $page=1; } else { $page=$_GET['page2']; }


require('inc/demo2.dubaimoon.com.php');
require('inc/uae.dubizzle.com.php');
require('inc/autos.souq.com.php');

function curPageURL() {
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
 return $pageURL;
}
$the_url1 = curPageURL();
$the_url1=preg_replace("/&page2=(.*)/", "", $the_url1);


$next=$page+1;
$prev=$page-1;
 echo '<div class="stranicirane">';
echo "<a href=\"$the_url1&page2=$prev\" class=\"left\" style=\"font-size:18px;\">Previous Page</a>";
echo '<p>Page:&nbsp;'.$page.'</p>';
echo "<a href=\"$the_url1&page2=$next\" class=\"right\" style=\"font-size:18px;\">Next Page</a>";
echo '</div>';

}
?>
  </div>
  <div style="clear:both"></div>
</div>
<script src="js/slider.js"></script>
</body>
</html>